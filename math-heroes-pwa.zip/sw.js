/* Math Heroes — MISI SIFIR | Service Worker
   Naikkan nombor versi di bawah setiap kali fail dikemas kini,
   supaya pengguna dapat versi terbaharu. */
const CACHE = 'math-heroes-v1';

const CORE = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './icon-maskable-512.png',
  './apple-touch-icon.png',
  './favicon-32.png'
];

// Pasang: simpan rangka aplikasi (app shell)
self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(CORE)).then(() => self.skipWaiting())
  );
});

// Aktif: buang cache versi lama
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Ambil: cache-first, fallback ke rangkaian; cache juga fon Google secara automatik
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  e.respondWith(
    caches.match(req).then((hit) => {
      if (hit) return hit;
      return fetch(req).then((res) => {
        try {
          const url = new URL(req.url);
          const cacheable = res && res.status === 200 &&
            (url.origin === location.origin || /fonts\.(googleapis|gstatic)\.com$/.test(url.host));
          if (cacheable) {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
        } catch (err) {}
        return res;
      }).catch(() => {
        // Bila luar talian & permintaan ialah navigasi halaman, pulangkan app shell
        if (req.mode === 'navigate') return caches.match('./index.html');
      });
    })
  );
});
